
let routers = {
    index:      __dirname + '/routes/index',     
}

module.exports = routers;